# CISC/CMPE 422: Formal Methods in Software Engineering (Fall 2022)
## Assignment 2: Object Modelling With Alloy
## Due date: Tuesday, October 25, 5pm EST (GitHub classroom and OnQ submission)

## Software
This assignment uses Alloy, an analysis tool for object models developed by the [Software Design Group](https://sdg.csail.mit.edu/) at MIT. Alloy is publicly available for Windows, Linux and Mac OS and there is extensive documentation for it, including a book, a collection of sample models, and the Stack Overflow forum. You can find pointers to all of this on the [Alloy webpage](http://alloytools.org). **Note that we will be using version 5.1.0, not version 6.0!** Alloy 5.1.0 can be downloaded [here](https://github.com/AlloyTools/org.alloytools.alloy/releases/tag/v5.1.0). Installation and invocation are straightforward: Just store the .jar file somewhere and type `java -jar <name>.jar` in a terminal window where `<name>` is the name of the Alloy jar file. Otherwise, Alloy also is installed in CasLab. 

## Learning Outcomes
The purpose of this assignment is to give you
- practical experience with
  - expressing objects and their relationships formally and declaratively using constraints expressed in first-order logic and a relational calculus, and
  - reasoning about objects, their relationships and operations on them using constraint solving, and
- an increased understanding of memory management and garbage collection.

## Questions
### Part I: Modeling Structure (Fundamental Memory Management Concepts) [22/110 points]

#### File to Edit

Please enter all your answer for this part into the given file [a2Part1.als](alloy/a2Part1.als).

#### Preparation 
Most programming languages store program data in two different parts of memory: the content of local variables and parameters of a method or procedure is stored in the *stack*, i.e., a contiguous, fixed-size block of memory locations, while instances of complex user-defined data structures or classes created during program execution are stored on the *heap*, i.e., a possibly non-contiguous collection of memory locations that can grow and shrink at runtime. Every heap location has an address that uniquely identifies it. Locations can store values. These values either represent data or are addresses. The Alloy object model below captures these central concepts and some of their relationships: 
```Alloy 
module A2Part1

abstract sig Loc { 
   content: lone Val                          // a location contains at most one value
}
sig SLoc extends Loc {}                       
sig HLoc extends Loc {}                       

sig Var {
   sloc: one SLoc                             // a variable has exactly one stack location
}

abstract sig Val {}      
sig Data extends Val {}                       
sig Addr extends Val {                        
   hloc: one HLoc                             // an address has exactly one heap location
}
```
We introduce the following terminology: Elements of the signatures `Loc`, `SLoc`, `HLoc`, and `Var`, will be called *locations*, *stack locations*, *heap locations*, and *variables*, respectively. Elements of signatures `Val`, `Data`, and `Addr` will be called *values*, *data*, and *addresses*, respectively. Given a variable `x`, suppose the stack location associated with `x` (i.e., `x.sloc`) has value `v` as content (i.e., `x.sloc.content = v`). In this case, we will say that *`x` stores, holds, contains, or has value `v`*. Given an address `a`, suppose the heap location associated with `a` has value `v` as content (i.e., `a.hloc.content = v`). In this case, we will say that *`a` stores, holds, contains, or has value `v`*. Note that variables and addresses do not necessarily have a value (i.e., `x.sloc.contents` or `a.hloc.contents` can evaluate to the empty set). If variable `x` stores an address `a`, we will say that *`x` points to or refers to `a`*. If address `a1` stores an address `a2`, we will say that *`a1` points to or refers to `a2`*. 

The model above does not include all relevant constraints and would allow instances that are unrealistic or inappropriate (e.g., values that are neither data nor addresses, or heap locations with no or more than one address). The constraints in the following fact rule out these unwanted instances. 
```Alloy
fact Basic {
   Val = Data+Addr                            // data and addresses are the only values (*)
   Loc = HLoc+SLoc                            // locations on the stack and heap are the only locations (*)
   all hl:HLoc | one hloc.hl                  // every heap location has exactly one address 
   all sl:SLoc | lone sloc.sl                 // every stack location belongs to at most one variable 
   all sl:SLoc | no sloc.sl => no sl.content  // stack locations not belonging to a variable are empty (*)
}
```
Note that most aspects (but not all) of this initial Alloy model can also be captured in a [UML class diagram](images/part1ClassDiagram_cropped.jpg). 
The only constraints not captured in this class diagram are the ones labelled `(*)` in the fact above. 

Use Alloy's `run` command as in, e.g., 
```Alloy
run scPrep1 {} for 1 
run scPrep2 {some Addr && some Var} for 3
run scPrep3 {some d:Data | some x1:Var, x2:Var-x1 | (x1.sloc).content=d && (x2.sloc).content=d} for 3
```
to create *scenarios*, i.e., Alloy instances satisfying all constraints expressed in the model and any additional constraints that are provided as arguments to the command. All of these instances should match our intuition about how locations, addresses, data, and variables are related (e.g., [here](images/instancePart1.jpg) is an instance produced in response to `scPrep3`). You may want to try addtional run commands with different constraints and scopes. To evaluate formulas or expressions in a particular instance, use the Evaluator. 

Note how the scope constraint impacts the instances that Alloy produces. Also, note that some constraints require a minimal scope to be satisfiable. E.g., running `scPrep2` would not produce any instance in scope 1, because according to the model having at least one address (`some Addr`) and at least one variable (`some Var`) requires at least two locations. 

In `scPrep3`, the expression `(x1.sloc).content` (which is equivalent to `x1.sloc.content`) evaluates to the value stored in variable `x1`. To facilitate access to the values held by variables or addresses, the model defines the following functions:
```Alloy
fun read[x:Var]: lone Val {
   x.sloc.content
}
fun read[a:Addr]: lone Val {
   a.hloc.content
}
```
Using these functions, `x` stores (or holds) value `v` iff `read[x]=v`. Similarly for addresses. Should `x` (or `a`) not hold a value, `read[x]` (or `read[a]`) will return the empty set. 

The model also defines read functions that dereference their argument once, i.e., functions that assume that the argument contains another address and then return the contents of that second address:
```Alloy
fun readAt[x:Var]: lone Val {
   read[read[x]]
}      
fun readAt[a:Addr]: lone Val {
   read[read[a]]
}
```
We can easily see how the dereferencing requires an additional read access. Should the arguments not contain an address, both functions will return the empty set (thus, `no readAt[a]` can mean that `a` points to an address not containing a value, or that `a` contains data instead of an address).

Use Alloy's `run` command and the Evaluator to experiment with these functions:
```Alloy
run scPrep4 {some a1,a2:Addr | read[a1]=read[a2]} for 3
run scPrep5 {some d:Data | some x1:Var, x2:Var-x1 | readAt[x1]=d && read[x2]=d} for 3
run scPrep6 {some d:Data | some x:Var | readAt[readAt[x]]=d} for 4
```
The `check` command allows you to check if all instances of the model (within a given scope) satisfy a certain property. 
For example, as mentioned, if an address `a` stores only data or no value at all, then `readAt[a]` will evaluate to the empty set. 
We can check this property with the command below:

```Alloy
check propPrep1 {all a:Addr | (no read[a] || (some d:Data | read[a]=d)) => no readAt[a]} for 6
```
Note, however, that the converse does not hold, because if `readAt[a]` returns the empty set it could be because the address pointed to by `a` is empty. Running the check
```Alloy
check propPrep2 {all a:Addr | no readAt[a] => (no read[a] || some d:Data | read[a]=d)} for 2
```
will point this out and produce counter examples such as [this one](images/instancePart1Prep.jpg).


#### Question 1: Cycles and aliases [6 points]
- **[3 points] Q1a (addresses can form cycles):** Complete `run` command `Q1a` to cause Alloy to generate instances that satify the following statement: *There are 3 different addresses such that the first points to the second, the second points to the third, and the third points back to the first*.
- **[3 points] Q1b (addresses can have aliases):** Complete the `check` command `Q1b` to check if the following property holds: *Addresses cannot have aliases, i.e., for every address `a`, there is at most one address that points to `a`*.

#### Question 2: What is 'garbage' anyway? [16 points]
Values on the heap can be become garbage, i.e., unusable, and may have to be collected (manually as in C or automatically as in Java or Python). The following two definitions of garbage are the most common.
- **[3 points] Q2a (reference-counting-based definition):** An address `a` is considered garbage iff there is no location that contains `a`, i.e., there is no variable or address that points to `a`. Complete the definition of the predicate `garbageRefC[a:Addr]` such that it holds precisely when `a` is garbage in the above sense. [Reference counting](https://en.wikipedia.org/wiki/Reference_counting) is used by [CPython](https://stackify.com/python-garbage-collection) and [smart pointers](https://en.wikipedia.org/wiki/Smart_pointer) are used in C++. 
- Based on reachability: An address `a` is considered garbage iff there is no variable from which it can be reached, i.e., there is no variable `x` that points to `a` directly or transitively. 
  - **[3 points] Q2b (reachability):** Complete the function `reachable[a:Addr] : set Addr` such that it returns the set of addresses that are reachable from `a` in zero or more 'points to' steps. Hint: make sure the function returns only addresses and no data.
  - **[2 points] Q2c (reachability-based definition):** Use function `reachable` to complete the predicate `garbageReach[a:Addr]` such that it holds precisely when `a` is garbage in the above sense. [Tracing garbage collection](https://en.wikipedia.org/wiki/Tracing_garbage_collection) is based on reachability and used in, e.g., Java. 
- **[0 points] Q2d:** Use the run command and the evaluator to check that your definitions work as expected. 
- We want to explore which definition of garbage collection is better. In terms of implementation effort, for example, it is often said that reference counting is easier to implement efficiently than checking reachability. But, we can also ask: do both definitions agree on what they consider garbage? Or, does one allow the identification of more garbage than the other? For each statement below, complete the corresponding assertion so that it captures the meaning of the statement: 
  - **[3 points] Q2e:** *An address that is considered garbage under the reference counting definition, will also be considered garbage under the reachability definition*
  - **[3 points] Q2f:** *An address that is considered garbage under the reachability definition, will also be considered garbage under the reference counting definition*
- **[2 points] Q2g:** Exactly one of the two assertions above should hold. Use the Alloy analyzer to determine which assertion holds and which fails. Use the analysis result to answer the question: Which definition is better in the sense that it identifies more garbage, and why?

### Part II: Modeling Behaviour (Fundamental Memory Management Operations) [53/110 points]

#### File to Edit
Enter all your answers for this part and Part III into the given file [a2Part2.als](alloy/a2Part2.als).

#### Preparation
We now want to add operations that can change the contents of variables and addresses (i.e., heap locations). For this to be possible, we make the `content` relation that keeps track of the values in each location mutable. More precisely, we add a signature `State` and replace the binary relation `content : lone Val` in signature `Loc` by a ternary relation `content : Loc -> lone Val` in `State`. Now, we can think of `content` as a map that takes *two* keys: given a state `s` and a location `l`, `l.(s.content)` denotes the value stored in `l` in state `s`. Note that relational composition is not associative; e.g., `x.sloc.(s.content)` is not the same as `x.sloc.s.content` (which is equivalent to `((x.sloc).s).content`).

Now, every state can have its own set of pairs mapping locations to values. But, also, a state is now required to look up the value of a variable or attribute. E.g., the expression `x.sloc.(s.content)` evaluates to the content of the stack location of variable `x` in state `s`. The model in `a2Part2.als` contains these changes and replaces, e.g., 
```Alloy
fun read[x:Var]: lone Val {
   x.sloc.content
}
```
from Part I by 
```Alloy
fun read[s:State,x:Var]: lone Val {
   x.sloc.(s.content)
}
```
Similar changes have been made to the remaining read functions and the facts. We say that variable `x` (address `a`) stores, contains, holds, or has value `v` in state `s` iff `read[s,x]=v` (`read[s,a]=v`). 

In the model `a2Part2.als`, signature `State` also has been given two addtional ternary relations `valA` and `valX` which are to provide more direct access to the content of an address or variable. Concretely, given a state `s`, and an address `a`, the additional constraint 
```Alloy
all s:State | s.valA = hloc.(s.content)
```
in fact `Basic` makes the expression `a.(s.valA)` be equivalent to `a.hloc.(s.content)`. As a result, `a.(s.valA)` represents the content of the location with address `a` in state `s`. In other words, we have `a.(s.valA) = s.hloc.(s.content) = read[s,a]`. Similarly, for `valX`. We can think of `valA` and `valX` as 'helper relations' which will make the instances produced by Alloy in this and the next part much more readable. 

#### Question 3: Adding state [0 points]
We want to use your definitions of the function `reachable` and the predicate `garbageReach` from Part I, but they also need to be adapted and made state-sensitive. 
- **[0 points] Q3a:** Use a slight modification of your definition of `reachable[a:Addr]:set Addr` to complete the definition of `reachable[s:State,a:Addr]:set Addr` such that it returns the set of addresses reachable from `a` in state `s` in zero or more 'points to' steps. 
- **[0 points] Q3b:** Use a slight modification of your definition of `garbageReach[a:Addr]` to complete the definition of `garbageReach[s:State,a:Addr]` such that it holds precisely when address `a` satisfies the reachability-based definition of garbage in state `s`. 
- **[0 points] Q3c:** Check that your new definitions work as expected, possibly through appropriately modified versions of run commands or assertion checks from Part I. 

**Customizing the visualization:** It is highly recommended that you customize the visualization of instances to increase readability. Go [here](doc/visualization.md) for more information on how to do this.

#### Question 4: Adding write operations [8 points]
Now, we are ready to define two write operations. We will do this by describing the relationship between a pre-state `s` and a post-state `s'`.  Complete the definitions of predicates `write` and `writeAt` as described below.
  - **[4 points] Q4a:** Predicate `write[s:State,v:Val,x:Var,s':State]` holds precisely iff the arguments satisfy the following:
      - variable `x` stores value `v` in state `s'`, 
      - `s` and `s'` agree at least on the values of all variables other than `x`, and
      - `s` and `s'` agree on the values of all addresses

    where we say that *`s` and `s'` agree on the value of a variable `x` (or address `a`) iff `x` (or `a`) has the same value (if any) in `s` and `s'`* (i.e., either `x` (or `a`) has the same value in `s` and `s'`, or `x` (or `a`) does not have any value in `s` and `s'`).
  - **[4 points] Q4b:** Predicate `writeAt[s:State,v:Val,x:Var,s':State]` holds precisely iff the arguments satisfy the following:
      - variable `x` stores an address in state `s`, i.e., `x` stores a value in `s` and that value is an address,
      - in state `s'`, the address pointed to by variable `x` stores value `v`,
      - `s` and `s'` agree on the values of all variables, and
      - `s` and `s'` agree at least on the values of all addresses other than the address pointed to by `x`.
  - **[0 points] Q4c:** Check that your predicates work as expected. E.g., the run command
    ```Alloy
    run Q4c1 {some s,s':State, v:Val, x:Var | write[s,v,x,s']} for 3
    ```
    should be able to generate an instance containing states `s` and `s'` where `s'` differs from `s` only in that `x` holds `v` in `s'`.
    Also, the assertion check 
    ```Alloy
    check Q4c2 {all s,s':State, v:Val, x:Var | write[s,v,x,s'] => (read[s',x]=v && all y:Var-x | read[s',y]=read[s,y])} for 6
    ```
    should succeed without counter example.

#### Question 5: Memory allocation [15 points]
- Before we can formalize memory allocation and collection, we need a way to keep track of the heap addresses that are in use and those that are not. 
  - **[2 points] Q5a:** Add a binary relation `used : set Addr` to signature `State`. The goal is that, given a state `s`, `s.used` evaluates to the set of heap addresses that are in use in state `s`. Add a line to the `write` and `writeAt` predicates of Question 4 to say that writing does not change the set of used addresses.
  - Unused addresses should satisfy certain properties. Formalize each of the following two statements in Alloy and add them to the fact `UnusedAddresses`.
    - **[3 points] Q5b:** *Unused addresses are empty, i.e., in every state `s`, if an address `a` is not used in `s`, then `a` does not store a value in `s`*
    - **[3 points] Q5c:** *Unused addresses cannot be stored as value anywhere, i.e., in every state `s`, if an address `a` is not used, then `a` is not contained in any location*
  - **[0 points] Q5d:** To validate your formalization, use the `run` command to generate instances that, e.g., contain at least one used and one unused address.
  - Complete assertion Q5e such that it captures the property below and use the Alloy analyzer to check it (hint: it should hold).
    - **[3 points] Q5e:** *In all states `s` and for all variables `x`, the addresses reachable from `x` in `s` are all used in `s`*.
- **[4 points] Q5f:** Now we can describe what it means to allocate new memory. In C, the effect of executing `x = malloc(...)` is that an unused heap address is found, stored in `x`, and then marked as used. Complete the definition of predicate `new[s:State,x:Var,s':State]` such that it holds precisely iff the following is satisfied:
     - states `s` and `s'` agree at least on the values of all variables other than `x`, and
     - in state `s`, there exists an address `a` that is unused in `s` such that the following hold:
       - in state `s'`, variable `x` stores address `a`,
       - in state `s'`, address `a` does not store any value,
       - in state `s'`, only address `a` is used in addition to addresses already used in `s`, and
       - states `s` and `s'` agree at least on the values of all addresses other than `a`.
- **[0 points] Q5g:** Use the `run` command to generate instances that satisfy `new[s,x,s']` for some states `s` and `s'` and variable `x`. Note that the predicate should fail if all heap addresses are used. 

#### Question 6: Garbage collection [30 points]
- We will first explore the relationship between memory operations and garbage. 
  - **[2 points] Q6a:** Using the reachability-based definition of garbage, complete function `garbage[s:State] : set Addr` such that it returns the set of all addresses that are used in `s` and are garbage. 
  - Our two read operations don't change the state and thus cannot create garbage. However, what about the write operations and memory allocation? For each of the statements below, create an assertion that captures its meaning.
    - **[3 points] Q6b:** *Writing data to a variable using `write` leaves the garbage unchanged*
    - **[3 points] Q6c:** *After the execution of `new[s,x,s']`, the address stored in `x` in `s'` is not garbage in `s'`*
    - **[3 points] Q6d:** *Two successive `new` operations involving the same variable result in exactly one additional garbage address on the heap*
  - **[3 points] Q6e:** Use the Alloy analyzer to determine which of these assertions hold (in increasing scopes up to 6). Hint: exactly one of the three assertions should fail.
- **[4 points] Q6f:** Garbage collection means that heap addresses that are considered garbage are reclaimed so that they can be used again. Complete the definition of the predicate `gc[s,s':State]` so that it holds precisely iff the difference between `s'`  and `s` captures the effect of a garbage collection step, i.e., iff the following statements hold:
  - the addresses used in `s'` are the non-garbage addresses used in `s`,
  - `s` and `s'` agree on the values of all variables, 
  - all addresses that were garbage in `s`, don't store any value in `s'`, and
  - `s` and `s'` agree at least on the values of all addresses that were not garbage in `s`.
- For each of the statements below, complete the corresponding assertion such that it captures the meaning of the statement:
  - **[3 points] Q6g:** *After a successful garbage collection step, there is no garbage*
  - **[3 points] Q6h:** *Garbage collection is idempotent, i.e., a second, consecutive garbage collection step leaves the state unchanged*
  - **[3 points] Q6i:** *The contents of addresses pointed to by variables do not change through a garbage collection step*
- **[3 points] Q6j:** Use the Alloy analyzer to determine which of these assertions hold (in increasing scopes up to 6). 
  
### Part III: Modeling Behaviour (Executions) [35/110 points]

#### File to Edit

Keep on using the same model file as for Part II. 

#### Preparation
To formalize executions, i.e., sequences of operations, we use Alloy's `ordering` module. In the model file, uncomment the line 
```Alloy
// open util/ordering[State]
```
to impose the constraints of the `ordering` module on elements of the `State` signature. In every instance, these constraints force the states in the instance to be linearly (totally) ordered. That is, for any two states in the instance, they will either be the same, or one will come before the other in the ordering. Also, a state is either the last (first) in the ordering, or it has exactly one successor (predecessor). See [models/util/ordering.als](alloy/ordering.als) (from Alloy's .jar file, but included in the directory `alloy/` of this assignment's repository for convenient reference), for descriptions of some of the functions (e.g., `first`, `last`, and `next`) and predicates (`lt`, `lte`, `gt`, and `gte`) that the `ordering` module comes with. Given an instance, use the Evaluator to experiment with these functions and predicates. The states in an instance (if any) will be called `State0`, `State1`, `State2`, ... (or, `State$0`, `State$1`, ... in the Evaluator) with `State0` being the first state and `State1` being its successor (i.e., `State0.next = State1`). Also, function `first` (from module `ordering`) will evaluate to the first state in the instance (i.e., `State0`), if any. In contrast, function `last` denotes the last state, if any. 


To model executions, we need to express that, in all instances, the successor of a state `s` is the result of applying one of our 3 state-changing operations `new`, `write`, or `writeAt` (we will add `gc` later). To achieve this, we will use predicate `init` and the fact `StateOrdering` as shown below:

```Alloy
pred init[s:State] {
   no s.used
}

fact StateOrdering {
   init[first] &&
   all s:State, s':s.next |
      ((some x:Var | 
     	  new[s,x,s'] ||         // disable for Q9
          (some d:Data | write[s,d,x,s'] || writeAt[s,d,x,s']) || 
          some y:Var | some read[s,y] && (write[s,read[s,y],x,s'] || writeAt[s,read[s,y],x,s']) ||
          some y:Var | some readAt[s,y] && (write[s,readAt[s,y],x,s'] || writeAt[s,readAt[s,y],x,s']))
      )
}
```

Adding `init` and `StateOrdering` to the model will ensure that:
- Executions start in a state satisfying `init`, i.e., a state in which all addresses are unused
- For any state `s` with successor `s'`, one of the following holds:
	- there exists a variable `x` such that `s` and `s'` are related via the `new` operation, i.e., `new[s,x,s']` holds, 
	- there exists a variable `x` and some data `d` such that `s` and `s'` are related via the `write` or `writeAt` operation, i.e., `write[s,d,x,s']` or `writeAt[s,d,x,s']` holds, 
	- there exists a variable `x` and some variable `y` such that `y` holds a value in `s`, and `s` and `s'` are related via the `write` or `writeAt` operation, i.e., `write[s,read[s,y],x,s']` or `writeAt[s,read[s,y],x,s']` holds, or
	- there exists a variable `x` and some variable `y` such that `y` points to an address holding a value in `s`, and `s` and `s'` are related via the `write` or `writeAt` operation, i.e., `write[s,readAt[s,y],x,s']` or `writeAt[s,readAt[s,y],x,s']` holds.

Copy and paste `init` and `StateOrdering` into your model. Now, the instances found by Alloy represent executions, and we can use Alloy to find executions with certain properties, or check that all executions satisfy a property. 

#### Question 7: Executions as Sequences of States [24 points]
- **[0 points]** Use the run commands below to generate executions that satisfy specific properties:
    ```Alloy
    run Q7a {#Addr>1 && last.used=Addr]} for 4
    run Q7b {some s:State,x:Var | new[s,x,s.next]} for 5
    ```
    `Q7a` will generate sequences of states that contain at least 2 addresses and that end in a state in which all addresses are used (such as [this one](images/instancePart3Q7a.jpg)). `Q7b` will give you sequences that contain at least one pair of adjacent states related by the `new` predicate (such as [this one](images/instancePart3Q7b.jpg)).
- Formalize each of the statements below, and use them in run commands to generate instances satisfying the statements. Note that all statements should be satisfiable in sufficiently large scopes.
	- **[3 points] Q7c:** *There exists a state `s` in which some data `d` is written to some variable `x` and there is a state `s'` that follows `s` 
		in which `x` no longer stores `d`*
	- **[3 points] Q7d:** *There exists a state with addresses forming a cycle of length 3*
	- **[3 points] Q7e:** *There is some data `d` such that there are exactly three states in which `d` is stored in some variable*
	- **[3 points] Q7f:** *There is a variable `x` such that in all states (except the last) some data is written to `x`*
- Formalize each of the following properties as assertions
	- **[3 points] Q7g:** If *`writeAt[s,v,x,s']`, then `s` and `s'` agree at least on the values of addresses pointed to by variables different from `x`*
	- **[3 points] Q7h:** *The last state has at least one used address iff there is a state in which a `new` was performed*
	- **[3 points] Q7i:** *Once an address becomes garbage, it will continue to be garbage* (this property is also described as *stability* or the slogan *"Once garbage, always garbage"*; stability greatly facilitates the implementation of garbage collection and most garbage collectors rely on it).
- **[3 points] Q7j:** Use the Alloy analyzer to determine which properties hold (hint: exactly two of the three properties should hold). 


#### Question 8: Enabling Explicit Garbage Collection [5 points]
- **[2 points] Q8a:** Change the fact `StateOrdering` in such a way that garbage collection (via predicate `gc[s,s':State]`) becomes a possible execution step. 
- **[0 points] Q8b:** Use the `run` command with (for example) the following to create executions in which garbage is collected:
   - `run 8b {some s:State | some garbage[s] && gc[s,s.next]} for 5`
- **[3 points] Q8c:** Re-run the assertion checks from Question 7. Which of the assertions Q7g, Q7h, and Q7i fail now? 

#### Question 9: Implicit Garbage Collection [6 points]
Predicate `gc[s,s':State]` formalizes explicit, possibly user-invoked garbage collection. 
Of course, collection can also take place implicitly without the user having to invoke it. 
Below, we integrate garbage collection and memory allocation. 
- **[5 points] Q9a:** Complete the predicate `newGC[s:State,x:Var,s':State]` such that it holds precisely when 
	- states `s` and `s'` agree at least on the values of all addresses that were not garbage in `s`, and on the values of variables other than `x`, and
	- the addresses that were garbage in `s` do not contain a value in `s'`, and
	- in state `s`, there exists an address `a` that is unused in `s` such that the following hold:
	  - in state `s'`, variable `x` stores address `a`, 
	  - in state `s'`, address `a` does not store any value, and
  	  - in state `s'`, an address is considered used iff either it is equal to `a` or it was used in `s` and not garbage in `s` (i.e., `a` becomes used and the garbage becomes unused).
- **[1 point] Q9b:** Modify the `StateOrdering` fact to enable `newGC` and disable `new` and `gc`. Then, use Alloy's analysis to check that your formulation of `newGC` works as expected with, e.g., 
  ```Alloy
  run Q9b1 {some s:State | some garbage[s] && no garbage[s.next] && some x:Var | newGC[s,x,s.next]} for 5
  ```
  Using `newGC` instead of `new` it is possible to execute certain sequences of garbage-producing operations (as considered, e.g., in Question Q6d) even with only small amounts of heap space. The `run` command below illustrates this by generalizing Question 6d and repeatedly assigning a newly allocated address to the same variable `x` such that the number of such allocations exceeds the size of the heap. Use command `Q9b2` to check that this is indeed possible. 
  ```Alloy
  run Q9b2 {some x:Var | all s:State-last | newGC[s,x,s.next]} for 7 but exactly 4 Loc
  ```
  In other words, with least three heap locations (and one stack location), `newGC[s,x,s.next]` can be applied successively an arbitrary number of times. 


### Part IV: Discussion [0 points]

- In `newGC` garbage is collected *eagerly*, i.e., whenever `newGC` is performed all garbage is collected. However, note that garbage can also be collected *lazily*, e.g., when `new` is invoked and all addresses are used or the number of unused addresses falls below a certain threshold. For applications with high, predictable performance requirements the behaviour of the garbage collector can be customized. For more information see, e.g., [here](https://stackify.com/what-is-java-garbage-collection), [here](https://stackify.com/python-garbage-collection/), or [here](https://www.cubrid.org/blog/3826456).
- Note how our model of memory management left out certain information (e.g., nature of data, the size of locations, how memory allocation and garbage collection are implemented). We abstracted from this information, because it was not relevant to our study. Good models only contain what is necessary.

## Instructions
**Important: Please follow the instructions below carefully. Points may be taken off, if you don't.**

- Only edit the files [a2Part1.als](alloy/a2Part1.als) and [a2Part2.als](alloy/a2Part2.als).

### Part I
- Put your answers into the given file `a2Part1.als` (see beginning of Part I). Please ensure that it is clear which (sub-)question each answer corresponds to.

### Parts II and III
- Put your answers into the given file `a2Part2.als` (see beginning of Part II). Please ensure that it is clear which (sub-)question each answer corresponds to.

**What and how to submit**

As for Assignments 1, submit your assignment before the deadline to **both** GitHub Classroom **and** OnQ. For the OnQ submission, download an archive of your repository **from GitHub** and upload it **as is** to OnQ (see submission instructions for Assignment 1 for more details).

