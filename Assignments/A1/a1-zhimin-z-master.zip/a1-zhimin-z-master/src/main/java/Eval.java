import ast.*;

import java.util.*;

public class Eval extends BaseEval {
    //-----------------------!! DO NOT MODIFY !!-------------------------
    private final int[][] M;
    public Eval(int[][] M) {
        this.M = M;
    }
    //-------------------------------------------------------------------

    /**
     * Helper function for Nat evaluation
     */
    protected Integer evalNat(Nat exp, Env env) {
        return exp.value;
    }

    /**
     * Helper function for AtomicN evaluation
     */
    protected Boolean evalAtomicN(AtomicN exp, Env env) {
        int lhs = evalNExp(exp.lhs, env);
        int rhs = evalNExp(exp.rhs, env);
        switch (exp.relNOp.kind) {
            case EQ:
                return lhs == rhs;
            case NEQ:
                return lhs != rhs;
            case LT:
                return lhs < rhs;
            case LTE:
                return lhs <= rhs;
            case GT:
                return lhs > rhs;
            case GTE:
                return lhs >= rhs;
        }
        return false;
    }

    /**
     * Helper function for AtomicS evaluation
     */
    protected Boolean evalAtomicS(AtomicS exp, Env env) {
        Set<Integer> lhs = evalSExp(exp.lhs, env);
        Set<Integer> rhs = evalSExp(exp.rhs, env);
        switch (exp.relSOp.kind) {
            case EQ:
                return lhs.equals(rhs);
        }
        return false;
    }

    /**
     * Helper function for Type evaluation
     */
    protected Set<Integer> evalType(Type exp, Env env) {
        Set<Integer> set = new HashSet<>();
        switch (exp.kind){
            case DAY:
                for (int day = 1; day <= this.M[0].length; day++){
                    set.add(day);
                }
                return set;
            case PRODUCT:
                for (int prod = 1; prod <= this.M.length; prod++){
                    set.add(prod);
                }
                return set;
            case SALE:
                for (int[] row: this.M) {
                    for (int sale: row) {
                        set.add(sale);
                    }
                }
                return set;
        }
        return null;
    }

    /**
     * Helper function for SalesForM evaluation
     */
    protected Integer evalSalesForM(SalesForM exp, Env env) {
        int sales = 0;
        for (int[] row: this.M) {
            for (int sale: row) {
                sales += sale;
            }
        }
        return sales;
    }

    /**
     * Helper function for SalesForD evaluation
     */
    protected Integer evalSalesForD(SalesForD exp, Env env) {
        int day = evalNExp(exp.day, env) - 1;
        int sales = 0;
        for (int[] row : this.M) {
            sales += row[day];
        }
        return sales;
    }

    /**
     * Helper function for SalesForP evaluation
     */
    protected Integer evalSalesForP(SalesForP exp, Env env) {
        int prod = evalNExp(exp.product, env) - 1;
        int sales = 0;
        for (int day = 0; day < this.M[0].length; day++) {
            sales += M[prod][day];
        }
        return sales;
    }

    /**
     * Helper function for SalesAt evaluation
     */
    protected Integer evalSalesAt(SalesAt exp, Env env) {
        int prod = evalNExp(exp.product, env) - 1;
        int day = evalNExp(exp.day, env) - 1;
        return this.M[prod][day];
    }

    /**
     * Helper function for BinaryNExp evaluation
     */
    protected Integer evalBinaryNExp(BinaryNExp exp, Env env) {
        BinNOp op = exp.op;
        Integer lhs = evalNExp(exp.lhs, env);
        Integer rhs = evalNExp(exp.rhs, env);
        switch (op.kind){
            case ADD:
                return lhs + rhs;
            case DIFF:
                return lhs - rhs;
            case MULT:
                return lhs * rhs;
            case DIV:
                if (0 == rhs){
                    throw new DivisionByZeroException();
                } return lhs / rhs;
        }
        return 0;
    }

    /**
     * Helper function for BinarySExp evaluation
     */
    protected Set<Integer> evalBinarySExp(BinarySExp exp, Env env) {
        BinSOp op = exp.op;
        Set<Integer> lhs = evalSExp(exp.lhs, env);
        Set<Integer> rhs = evalSExp(exp.rhs, env);
        switch (op.kind){
            case UNION:
                lhs.addAll(rhs);
                return lhs;
            case DIFF:
                lhs.removeAll(rhs);
                return lhs;
            case INTER:
                lhs.retainAll(rhs);
                return lhs;
        }
        return null;
    }

    /**
     * Helper function for Unary evaluation
     */
    protected Boolean evalUnary(Unary exp, Env env) {
        UnaryConn unConn = exp.unConn;
        Boolean formula = evalFormula(exp.formula, env);
        switch (unConn.kind){
            case NOT:
                return !formula;
        }
        return false;
    }

    /**
     * Helper function for Binary evaluation
     */
    protected Boolean evalBinary(Binary exp, Env env) {
        BinaryConn formula = exp.binConn;
        Boolean lhs = evalFormula(exp.lhs, env);
        Boolean rhs = evalFormula(exp.rhs, env);
        switch (formula.kind){
            case AND:
                return lhs && rhs;
            case OR:
                return lhs || rhs;
            case IMPLY:
                return !lhs || rhs;
            case EQUIV:
                return (!lhs || rhs) && (lhs || !rhs);
        }
        return false;
    }

    /**
     * Helper function for Size evaluation
     */
    protected Integer evalSize(Size exp, Env env) {
        Set<Integer> set = evalSExp(exp.sExp, env);
        return set.size();
    }

    /**
     * Helper function for Quantified evaluation
     */
    protected Boolean evalQuantified(Quantified exp, Env env) {
        Set<Integer> set = evalType(exp.type, env);
        String varName = exp.var.name;
        Formula formula = exp.formula;
        switch (exp.quantifier.kind){
            case FORALL:
                for (int value: set) {
                    env.push(varName, value);
                    Boolean formulaBool = evalFormula(formula, env);
                    env.pop();
                    if(!formulaBool){
                        return false;
                    }
                }
                return true;
            case EXISTS:
                for (int value: set) {
                    env.push(varName, value);
                    Boolean formulaBool = evalFormula(formula, env);
                    env.pop();
                    if(formulaBool){
                        return true;
                    }
                }
                return false;
        }
        return false;
    }

    /**
     * Helper function for SetCompr evaluation
     */
    protected Set<Integer> evalSetCompr(SetCompr exp, Env env) {
        Set<Integer> set = evalType(exp.type, env);
        Set<Integer> setCompr = new HashSet<>();
        Formula formula = exp.formula;
        String valName = exp.var.name;
        for (int value: set) {
            env.push(valName, value);
            Boolean formulaBool = evalFormula(formula, env);
            if(formulaBool){
                setCompr.add(value);
            }
        }
        return setCompr;
    }

    @Override
    protected Integer evalNExp(NExp exp, Env env) {
        if(exp instanceof Nat){
            return evalNat((Nat) exp, env);
        } else if (exp instanceof SalesForM) {
            return evalSalesForM((SalesForM) exp, env);
        } else if (exp instanceof SalesAt) {
            return evalSalesAt((SalesAt) exp, env);
        } else if (exp instanceof SalesForD) {
            return evalSalesForD((SalesForD) exp, env);
        } else if (exp instanceof SalesForP) {
            return evalSalesForP((SalesForP) exp, env);
        } else if (exp instanceof BinaryNExp) {
            return evalBinaryNExp((BinaryNExp) exp, env);
        } else if (exp instanceof Size) {
            return evalSize((Size) exp, env);
        } else if (exp instanceof Var) {
            int value = env.lookup(((Var) exp).name);
            if(-1 == value){
                throw new UnboundVariableException();
            }
            return value;
        }
        return 0;
    }

    @Override
    protected Set<Integer> evalSExp(SExp exp, Env env) {
        if(exp instanceof Type){
            return evalType((Type) exp, env);
        } else if (exp instanceof BinarySExp) {
            return evalBinarySExp((BinarySExp) exp, env);
        } else if (exp instanceof SetCompr) {
            return evalSetCompr((SetCompr) exp, env);
        }
        return null;
    }

    @Override
    protected Boolean evalFormula(Formula formula, Env env) {
        if(formula instanceof AtomicN){
            return evalAtomicN((AtomicN) formula, env);
        } else if (formula instanceof AtomicS) {
            return evalAtomicS((AtomicS) formula, env);
        } else if (formula instanceof Unary) {
            return evalUnary((Unary) formula, env);
        } else if (formula instanceof Binary) {
            return evalBinary((Binary) formula, env);
        } else if (formula instanceof Quantified) {
            return evalQuantified((Quantified) formula, env);
        }
        return false;
    }
}
