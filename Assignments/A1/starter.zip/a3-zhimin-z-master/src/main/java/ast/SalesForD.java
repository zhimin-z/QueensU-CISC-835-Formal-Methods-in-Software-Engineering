package ast;

public class SalesForD extends NExp {
    public NExp day;

    public SalesForD(NExp day) {
        this.day = day;
    }
}
