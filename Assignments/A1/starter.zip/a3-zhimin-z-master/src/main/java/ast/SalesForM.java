package ast;

public class SalesForM extends NExp {

}
