package ast;

public interface ASTNode {
}
