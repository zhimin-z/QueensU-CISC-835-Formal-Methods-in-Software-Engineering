package ast;

public class Size extends NExp {
    public SExp sExp;

    public Size(SExp sExp) {
        this.sExp = sExp;
    }
}
